Resources can be downloaded from [http://cldr.unicode.org/index/downloads](http://cldr.unicode.org/index/downloads)

extract them under the data folder in this directory.

If any errors, or problems with the CLDR rules are encountered I strongly encourage contributing to the CLDR project and/or
adding the exceptions to `generate_resources.go`; any changes/fixes made directly to the generated locales will be rejected.